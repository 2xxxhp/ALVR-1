﻿namespace BeatLeader.Replayer.Emulation {
    internal class VRControllerEmulator : VRController {
        private new void Awake() { }
        private new void Update() { }
    }
}
