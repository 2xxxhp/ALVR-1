﻿namespace BeatLeader.API {
    public enum RequestState {
        Uninitialized,
        Started,
        Finished,
        Failed
    }
}