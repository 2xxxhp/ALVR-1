﻿namespace BeatLeader.Models {
    public enum FileStatus {
        Unloaded,
        Loading,
        Loaded,
        Corrupted,
        Deleted
    }
}