﻿namespace BeatLeader.Models
{
    public interface ILateInitializable
    {
        void LateInitialize();
    }
}
