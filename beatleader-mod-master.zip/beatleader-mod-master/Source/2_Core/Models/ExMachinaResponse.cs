﻿namespace BeatLeader.Models {
    internal struct ExMachinaBasicResponse {
        public float balanced;
    }
}