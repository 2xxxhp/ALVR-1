﻿namespace BeatLeader.Models {
    public enum PlayerRole {
        Default,
        Admin,
        RankedTeam,
        JuniorRankedTeam,
        Mapper,
        Creator,
        Tipper,
        Supporter,
        Sponsor,
    }
}