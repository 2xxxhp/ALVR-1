﻿namespace BeatLeader.Models
{
    internal enum ScoresScope {
        Global,
        Friends,
        Country
    }
}
