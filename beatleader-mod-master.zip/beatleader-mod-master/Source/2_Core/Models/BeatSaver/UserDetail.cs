﻿using JetBrains.Annotations;

namespace BeatLeader.Models.BeatSaver {
    [UsedImplicitly(ImplicitUseTargetFlags.WithMembers)]
    internal class UserDetail {
        public string? name;
    }
}