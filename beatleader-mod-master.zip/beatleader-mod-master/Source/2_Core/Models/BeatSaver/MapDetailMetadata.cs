﻿using JetBrains.Annotations;

namespace BeatLeader.Models.BeatSaver {
    [UsedImplicitly(ImplicitUseTargetFlags.WithMembers)]
    public class MapDetailMetadata {
        public string? songName;
        public string? levelAuthorName;
    }
}