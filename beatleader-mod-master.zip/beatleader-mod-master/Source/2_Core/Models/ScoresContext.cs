namespace BeatLeader.Models {
    internal enum ScoresContext {
        Standard,
        Modifiers
    }
}