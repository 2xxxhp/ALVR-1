namespace BeatLeader.Models {
    internal struct OculusUserInfo {
        public string id;
        public string name;
        public string avatar;
        public bool migrated;
        public string migratedId;
    }
}