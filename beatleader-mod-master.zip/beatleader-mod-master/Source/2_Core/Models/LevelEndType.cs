﻿namespace BeatLeader.Models {
    public enum LevelEndType {
        Unknown = 0,
        Clear = 1,
        Fail = 2,
        Restart = 3,
        Quit = 4
    }
}