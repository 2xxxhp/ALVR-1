﻿using UnityEngine;

namespace BeatLeader.Models {
    internal interface ILayoutGrid : ILayoutGridModel {
        Vector2 Size { get; }
    }
}
