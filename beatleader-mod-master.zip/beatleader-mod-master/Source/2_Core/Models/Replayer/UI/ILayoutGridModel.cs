﻿namespace BeatLeader.Models {
    internal interface ILayoutGridModel {
        float CellSize { get; }
        float LineThickness { get; }
    }
}
