﻿namespace BeatLeader.Themes {
    public enum ThemeType {
        Unknown,
        Booster,
        TheSun,
        TheMoon,
        TheStar,
        Sparks,
        Special
    }
}