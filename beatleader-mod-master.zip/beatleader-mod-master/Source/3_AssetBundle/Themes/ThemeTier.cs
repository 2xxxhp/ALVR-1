﻿namespace BeatLeader.Themes {
    public enum ThemeTier {
        Unknown,
        Tier1,
        Tier2,
        Tier3
    }
}