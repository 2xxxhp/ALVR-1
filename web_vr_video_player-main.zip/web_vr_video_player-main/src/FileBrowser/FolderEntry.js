export default class FolderEntry {
    name
    list
    
    constructor(name) {
        this.name = name;
        this.list = [];
    }
}