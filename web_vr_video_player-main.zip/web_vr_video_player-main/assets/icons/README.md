## Icons are licensed under "Free for commercial use with attribution license"

Icons made by 

[nawicon](https://www.flaticon.com/authors/nawicon)

[alfanz](https://www.flaticon.com/authors/alfanz)

[ayub-irawan](https://www.flaticon.com/authors/ayub-irawan)

[us-and-up](https://www.flaticon.com/authors/us-and-up)

[freepik](https://www.flaticon.com/authors/freepik)

from
[www.flaticon.com](http://www.flaticon.com/)
